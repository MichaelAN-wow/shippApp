jQuery Flot Animator
============

jQuery Flot Animator v1.0

Flot Animator is a free jQuery Plugin that will add fluid animations to any Flot chart.

See it in action => http://www.codicode.com/demo/flotanimator/
