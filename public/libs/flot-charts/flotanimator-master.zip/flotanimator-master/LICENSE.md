Available under Creative Commons Attribution 3.0 Unported License,
You can use it freely for commercial and personal projects.

by Chtiwi Malek,
http://www.codicode.com
